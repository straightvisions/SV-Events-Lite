DROP TABLE IF EXISTS `#__sv_events_lite_events`;
DROP TABLE IF EXISTS `#__sv_events_lite_categories`;
